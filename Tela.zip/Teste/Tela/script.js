// Armazena projetos em memória (array)
let projetos = [];

// Utilitário: formata data de yyyy-mm-dd para dd/mm/yyyy
function formatarData(data) {
    if (!data) return '—';
    const [y, m, d] = data.split('-');
    return `${d}/${m}/${y}`;
}

// Alterna abas
function mostrarAba(nome) {
    document.querySelectorAll('.aba').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById('aba-' + nome).style.display = 'block';
    event.target.classList.add('active');

    if (nome === 'funcionarios') carregarProjetosNoSelect();
    if (nome === 'lista') listarProjetos();
}

// Atualiza o <select> de projetos no formulário de funcionário
function carregarProjetosNoSelect() {
    const select = document.getElementById('projetoAssociado');
    select.innerHTML = '<option value="">Selecione um projeto</option>';
    projetos.forEach((p, i) => {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = p.nome;
        select.appendChild(opt);
    });
}

// Renderiza a tabela de projetos
function listarProjetos() {
    const tbody = document.querySelector('#tabelaProjetos tbody');
    tbody.innerHTML = '';

    if (projetos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Nenhum projeto cadastrado.</td></tr>';
        return;
    }

    projetos.forEach((p, i) => {
        const tr = document.createElement('tr');
        const funcionariosTexto = p.funcionarios.length > 0
            ? p.funcionarios.map(f => `${f.nome} (${f.setor})`).join(', ')
            : 'Nenhum';

        tr.innerHTML = `
            <td>${p.nome}</td>
            <td>${p.descricao}</td>
            <td>${formatarData(p.inicio)}</td>
            <td>${formatarData(p.fim)}</td>
            <td>${funcionariosTexto}</td>
            <td><button class="btn-danger" onclick="removerProjeto(${i})">Remover</button></td>
        `;
        tbody.appendChild(tr);
    });
}

// Remove um projeto pelo índice
function removerProjeto(index) {
    if (confirm('Deseja realmente remover este projeto?')) {
        projetos.splice(index, 1);
        listarProjetos();
    }
}

// Cadastro de projeto
document.getElementById('formProjeto').addEventListener('submit', function(e) {
    e.preventDefault();
    const erro = document.getElementById('erroProjeto');
    erro.style.display = 'none';

    const nome     = document.getElementById('nomeProjeto').value.trim();
    const descricao = document.getElementById('descricao').value.trim();
    const inicio   = document.getElementById('inicio').value;
    const fim      = document.getElementById('fim').value;

    if (!nome || !descricao || !inicio || !fim) {
        erro.textContent = 'Preencha todos os campos.';
        erro.style.display = 'block';
        return;
    }
    if (fim < inicio) {
        erro.textContent = 'A data de fim não pode ser anterior ao início.';
        erro.style.display = 'block';
        return;
    }

    projetos.push({ nome, descricao, inicio, fim, funcionarios: [] });
    this.reset();
    alert(`Projeto "${nome}" cadastrado com sucesso!`);
});

// Cadastro de funcionário
document.getElementById('formFuncionario').addEventListener('submit', function(e) {
    e.preventDefault();
    const erro = document.getElementById('erroFuncionario');
    erro.style.display = 'none';

    const nome    = document.getElementById('nomeFuncionario').value.trim();
    const setor   = document.getElementById('setor').value.trim();
    const idx     = document.getElementById('projetoAssociado').value;

    if (!nome || !setor || idx === '') {
        erro.textContent = 'Preencha todos os campos e selecione um projeto.';
        erro.style.display = 'block';
        return;
    }

    projetos[idx].funcionarios.push({ nome, setor });
    this.reset();
    alert(`Funcionário "${nome}" adicionado ao projeto "${projetos[idx].nome}"!`);
});
