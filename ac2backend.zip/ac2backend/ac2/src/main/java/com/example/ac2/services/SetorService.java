package com.example.ac2.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.ac2.models.Setor;
import com.example.ac2.repositories.SetorRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SetorService {

    private final SetorRepository setorRepository;

    public Setor salvar(Setor setor) {
        return setorRepository.save(setor);
    }

    public List<Setor> listar() {
        return setorRepository.findAll();
    }

    public Setor buscarPorId(Integer id) {
        return setorRepository.findById(id).orElse(null);
    }
}