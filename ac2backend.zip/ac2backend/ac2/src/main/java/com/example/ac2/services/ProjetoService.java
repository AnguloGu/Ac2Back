package com.example.ac2.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.ac2.models.Projeto;
import com.example.ac2.repositories.ProjetoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProjetoService {

    private final ProjetoRepository projetoRepository;

    public Projeto salvar(Projeto projeto) {
        return projetoRepository.save(projeto);
    }

    public List<Projeto> listar() {
        return projetoRepository.findAll();
    }

    // Buscar Projeto por ID
    public Projeto buscarPorId(Integer id) {
        return projetoRepository.findById(id).orElse(null);
    }

    // Buscar Projetos por intervalo de data
    public List<Projeto> buscarPorPeriodo(LocalDate dataInicio, LocalDate dataFim) {
        return projetoRepository.findByDataInicioBetween(dataInicio, dataFim);
    }

    // Buscar Projetos por ID do Funcionário
    public List<Projeto> buscarPorFuncionario(Integer funcionarioId) {
        return projetoRepository.findByFuncionariosId(funcionarioId);
    }
}