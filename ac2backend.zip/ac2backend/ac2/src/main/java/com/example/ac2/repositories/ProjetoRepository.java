package com.example.ac2.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ac2.models.Projeto;

public interface ProjetoRepository extends JpaRepository<Projeto, Integer> {

    // Buscar projetos entre um intervalo de datas
    List<Projeto> findByDataInicioBetween(LocalDate dataInicio, LocalDate dataFim);

    // Buscar projetos por ID de funcionário
    List<Projeto> findByFuncionariosId(Integer funcionarioId);
}