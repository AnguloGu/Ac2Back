package com.example.ac2;

import java.time.LocalDate;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.ac2.models.Funcionario;
import com.example.ac2.models.Projeto;
import com.example.ac2.models.Setor;
import com.example.ac2.repositories.FuncionarioRepository;
import com.example.ac2.repositories.ProjetoRepository;
import com.example.ac2.repositories.SetorRepository;

@SpringBootApplication
public class Ac2Application {

    public static void main(String[] args) {
        SpringApplication.run(Ac2Application.class, args);  // Inicializa a aplicação Spring Boot
    }

    @Bean
    public CommandLineRunner init(
            SetorRepository setorRepository,
            ProjetoRepository projetoRepository,
            FuncionarioRepository funcionarioRepository) {
        return args -> {
            System.out.println("*** INSERINDO DADOS INICIAIS ***");

            // Inserindo dados iniciais de Setores
            Setor setor1 = new Setor(null, "Tecnologia da Informação", null);
            Setor setor2 = new Setor(null, "Recursos Humanos", null);
            setorRepository.save(setor1);
            setorRepository.save(setor2);

            // Inserindo dados iniciais de Projetos
            Projeto projeto1 = new Projeto(null, "Novo Projeto de TI", LocalDate.of(2026, 5, 1), LocalDate.of(2026, 12, 1), null);
            projetoRepository.save(projeto1);

            // Inserindo dados iniciais de Funcionários
            Funcionario funcionario1 = new Funcionario(null, "João Silva", setor1, projeto1);
            Funcionario funcionario2 = new Funcionario(null, "Maria Santos", setor2, projeto1);
            funcionarioRepository.save(funcionario1);
            funcionarioRepository.save(funcionario2);

            // Consultando Funcionários (agora sem salário)
            System.out.println("\n*** LISTANDO FUNCIONÁRIOS ***");
            funcionarioRepository.findAll().forEach(f -> System.out.println(f.getNome()));

            // Consultar Projetos
            System.out.println("\n*** LISTANDO PROJETOS ***");
            projetoRepository.findAll().forEach(p -> System.out.println(p.getDescricao()));
        };
    }
}