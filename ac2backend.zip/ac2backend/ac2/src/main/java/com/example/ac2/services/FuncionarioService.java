package com.example.ac2.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.ac2.models.Funcionario;
import com.example.ac2.repositories.FuncionarioRepository;

@Service
public class FuncionarioService {

    private final FuncionarioRepository funcionarioRepository;

    public FuncionarioService(FuncionarioRepository funcionarioRepository) {
        this.funcionarioRepository = funcionarioRepository;
    }

    public Funcionario salvar(Funcionario funcionario) {
        return funcionarioRepository.save(funcionario);
    }

    public List<Funcionario> listar() {
        return funcionarioRepository.findAll();
    }

    // Buscar Funcionários pelo ID, agora com Optional
    public Optional<Funcionario> buscarPorId(Integer funcionarioId) {
        return funcionarioRepository.findById(funcionarioId);  // Retorna um Optional
    }
}