package com.example.ac2.controllers;

import com.example.ac2.models.Projeto;
import com.example.ac2.services.ProjetoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/projetos")
@RequiredArgsConstructor
public class ProjetoController {

    private final ProjetoService projetoService;

    @PostMapping
    public Projeto adicionar(@RequestBody Projeto projeto) {
        return projetoService.salvar(projeto);
    }

    @GetMapping
    public List<Projeto> listar() {
        return projetoService.listar();
    }

    @GetMapping("/{id}")
    public Projeto buscarPorId(@PathVariable Integer id) {
        return projetoService.buscarPorId(id);
    }

    @GetMapping("/periodo")
    public List<Projeto> buscarPorPeriodo(@RequestParam LocalDate inicio, @RequestParam LocalDate fim) {
        return projetoService.buscarPorPeriodo(inicio, fim);
    }

    @GetMapping("/funcionario/{id}")
    public List<Projeto> buscarPorFuncionario(@PathVariable Integer id) {
        return projetoService.buscarPorFuncionario(id);
    }
}