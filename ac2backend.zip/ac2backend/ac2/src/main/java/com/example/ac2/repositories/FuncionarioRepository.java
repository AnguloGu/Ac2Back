package com.example.ac2.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ac2.models.Funcionario;  // Use Optional

public interface FuncionarioRepository extends JpaRepository<Funcionario, Integer> {

    // Método que recebe o ID do funcionário e retorna o funcionário com seus dados
    @Override
    Optional<Funcionario> findById(Integer funcionarioId);  // Usando Optional
}